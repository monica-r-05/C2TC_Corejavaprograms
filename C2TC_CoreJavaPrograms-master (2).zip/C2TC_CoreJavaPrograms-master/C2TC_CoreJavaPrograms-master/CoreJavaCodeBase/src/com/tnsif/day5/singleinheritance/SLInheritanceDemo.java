//Program to demonstrate Single Inheritance 
package com.tnsif.day5.singleinheritance;

public class SLInheritanceDemo {

	public static void main(String[] args) {
		
		Student student = new Student("Gayatri", "8080808080", "Bangalore", 9888878787L, 10, "City College");
		System.out.println(student);
	}
}