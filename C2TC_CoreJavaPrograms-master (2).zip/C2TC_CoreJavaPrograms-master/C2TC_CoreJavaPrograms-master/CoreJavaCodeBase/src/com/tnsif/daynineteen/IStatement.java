//Program to demonstrate Functional Interface

package com.tnsif.daynineteen;

@FunctionalInterface // interface is declared with only one abstract method
interface IStatement {
	public String show();// abstract Method
	
}