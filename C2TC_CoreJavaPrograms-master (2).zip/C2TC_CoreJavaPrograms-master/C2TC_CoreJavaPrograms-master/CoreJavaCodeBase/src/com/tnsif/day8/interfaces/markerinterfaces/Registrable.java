//Program to demonstrate Marker Interface
package com.tnsif.day8.interfaces.markerinterfaces;

public interface Registrable {

}
