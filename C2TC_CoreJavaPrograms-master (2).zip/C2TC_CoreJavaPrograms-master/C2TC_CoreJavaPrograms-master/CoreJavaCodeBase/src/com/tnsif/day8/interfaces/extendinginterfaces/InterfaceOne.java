//InterfaceOne declaration
package com.tnsif.day8.interfaces.extendinginterfaces;

interface InterfaceOne{  
  void print();  
}  

