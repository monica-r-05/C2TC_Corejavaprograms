//Program to demonstrate class and object 
package com.tnsif.daythree.encapsulation;

public class EncapsulationDemo {
	public static void main(String[] args) {
		
		//object creation 
		OopsConceptDemo obj = new OopsConceptDemo();
		obj.setSerialNum(101);
		obj.setName("Pooja");
		obj.setAge(20);
		System.out.println(obj);
		
	}

}
