//Demonstration of simple java program
package com.tnsif.dayone;

public class FirstProgram {
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}